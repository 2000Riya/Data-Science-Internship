# Data-Science-Internship
The-Sparks-Foundation 
#1 Prediction using Supervised Machine Learning 
● Predict the percentage of marks of an student based on the number of study hours 
● This is a simple linear regression task as it involves just 2 variables.  
● You can use R, Python, SAS Enterprise Miner or any o
ther tool  
● Data can be found at http://bit.ly/w-data 
● What will be predicted score if a student studies for 9.25 hrs/ day?
